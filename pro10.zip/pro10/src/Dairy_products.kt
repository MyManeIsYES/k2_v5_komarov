class Dairy_products(_name:String, _price:Double, _manufacturer:String, _weight: Double) : Products(_name,_price, _manufacturer, _weight){
    override var name: String=_name
    override var price: Double=_price
    override var manufacturer:String=_manufacturer

    override var weight: Double=_weight

    var fat_content: Double=0.0

    override fun Info(): String {
        return "name: $name\nprice: $price\nmanufacturer: $manufacturer\nweight: $weight\nfat_content: $fat_content"
    }

    fun Amount_of_fat(i:Int):Double{
        return weight*fat_content*i
    }

}