interface Interface1 {
    var name:String
    var price: Double
    var manufacturer:String
    fun Info():String
}