import kotlinx.coroutines.*
suspend fun main()=try {
    var dairyProducts1=Dairy_products("МОЛОКО",99.8,"Молочный завод №14", 100.6)
    dairyProducts1.fat_content=3.2
    print("n=")
    var n= readLine()!!.toInt()
    println(dairyProducts1.Info())
    GlobalScope.launch {
        for(i in 1..n){
            println("$i Amount_of_fat: ${dairyProducts1.Amount_of_fat(i)}")
            delay(1000L)
        }
    }


    delay(1000L*n)
}
catch (e:NumberFormatException){println("error")}
