abstract class Products(var _name:String,var _price:Double,var _manufacturer:String,var _weight: Double) :Interface1 {
    override  abstract var name: String
    override abstract  var price: Double
    override abstract  var manufacturer:String

    abstract var weight: Double
    override abstract fun Info():String
}